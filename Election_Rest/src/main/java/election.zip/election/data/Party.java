package election.data;

import java.util.Random;


public class Party {
    private String partyID;
    private int amountVotes;

    public Party(String partyID) {
        this.partyID = partyID;
        this.amountVotes = new Random().nextInt(400) + 100;
    }

    public String getPartyID() {
        return partyID;
    }

    public int getAmountVotes() {
        return amountVotes;
    }

}
