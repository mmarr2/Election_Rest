package election.model;

import election.data.ElectionData;
import election.data.Party;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ElectionController {

    @RequestMapping("/")
    public String electionMain(){
        return "Election Data \n" + "<a href='http://localhost:8080/election/12345/data'>Link to election/12345/data</a><br/>";
    }


    @RequestMapping(value="/election/{regionID}/data", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ElectionData election(@PathVariable String regionID){
        ElectionData data = new ElectionData(regionID, "Linz Bahnhof", "Bahnhofsstrasse 27/9", "Linz", "Austria");
        return data;
    }
}
