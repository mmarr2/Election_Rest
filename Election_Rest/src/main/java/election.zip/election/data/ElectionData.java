package election.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class ElectionData {
    private String regionID;
    private String regionName;
    private String regionAddress;
    private String regionPostalCode;
    private String federalState;
    private String timestamp;

    private List<Party> parties = Arrays.asList(
            new Party("OEVP"),
            new Party("SPOE"),
            new Party("FPOE"),
            new Party("GRUENE"),
            new Party("NEOS")
    );

    private List<Vorzug> vorzüge = Arrays.asList(
            new Vorzug("Karl Nehammer"),
            new Vorzug("Andreas Babler"),
            new Vorzug("Herbert Kickl"),
            new Vorzug("Werner Kogler"),
            new Vorzug("Beate Meinl-Reisinger")
    );

    public ElectionData(String regionID, String regionName, String regionAddress, String regionPostalCode, String federalState) {
        this.regionID = regionID;
        this.regionName = regionName;
        this.regionAddress = regionAddress;
        this.regionPostalCode = regionPostalCode;
        this.federalState = federalState;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    // Getters

    public String getRegionID() {
        return regionID;
    }

    public String getRegionName() {
        return regionName;
    }

    public String getRegionAddress() {
        return regionAddress;
    }

    public String getRegionPostalCode() {
        return regionPostalCode;
    }

    public String getFederalState() {
        return federalState;
    }

    public String getTimestamp() {
        return timestamp;
    }


    public List<Party> getParties() {
        return parties;
    }

    public List<Vorzug> getVorzüge() {
        return vorzüge;
    }
}
