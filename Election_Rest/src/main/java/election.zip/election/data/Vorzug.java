package election.data;

import java.util.Random;

public class Vorzug {

    private String name;
    private int amountVotes;

    public Vorzug(String name){
        this.name = name;
        this.amountVotes = new Random().nextInt(400) + 100;
    }

    public String getName() {
        return name;
    }

    public int getAmountVotes() {
        return amountVotes;
    }
}
